﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Admin
{
    public class ManageResourcesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
