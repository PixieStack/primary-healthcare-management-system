﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Patient
{
    public class ViewAppointmentsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
