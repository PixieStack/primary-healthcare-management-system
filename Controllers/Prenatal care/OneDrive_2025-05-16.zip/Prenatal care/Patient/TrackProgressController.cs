﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Patient
{
    public class TrackProgressController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
