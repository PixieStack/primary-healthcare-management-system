﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Patient
{
    public class ViewResourcesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
