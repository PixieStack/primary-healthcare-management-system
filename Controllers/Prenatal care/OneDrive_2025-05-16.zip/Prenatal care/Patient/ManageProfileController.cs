﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Patient
{
    public class ManageProfileController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
