﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Doctor
{
    public class PrenatalDoctorOrderTestsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
