﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Doctor
{
    public class PrenatalDoctorReportsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
