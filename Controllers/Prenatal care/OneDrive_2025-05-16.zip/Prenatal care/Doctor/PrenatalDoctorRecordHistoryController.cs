﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Doctor
{
    public class PrenatalDoctorRecordHistoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
