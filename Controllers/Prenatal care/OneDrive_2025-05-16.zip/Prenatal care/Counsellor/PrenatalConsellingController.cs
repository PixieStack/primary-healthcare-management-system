﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers
{
    public class PrenatalConsellingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
