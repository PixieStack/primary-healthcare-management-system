﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers.Prenatal_care.Counsellor
{
    public class PostpartumController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
