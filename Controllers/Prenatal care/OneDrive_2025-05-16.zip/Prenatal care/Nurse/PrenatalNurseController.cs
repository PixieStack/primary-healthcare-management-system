﻿using Microsoft.AspNetCore.Mvc;

namespace CodeMed.Controllers
{
    public class PrenatalNurseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
